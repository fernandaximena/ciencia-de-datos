# Importar librerías necesarias
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# ------------------------------------------------------
# Paso 1: Generación y Exploración de Datos
# ------------------------------------------------------
np.random.seed(123)  # Equivalente a set.seed() en R
n = 300

# Crear DataFrame con las métricas simuladas
datos_red = pd.DataFrame({
    'duracion_ms': np.random.normal(50, 10, n),
    'paquetes_enviados': np.random.normal(100, 20, n),
    'bytes_enviados': np.nan,  # Se calculará después
    'errores_checksum': np.random.poisson(2, n),
    'reintentos_tcp': np.nan,
    'latencia_avg': np.random.normal(15, 5, n),
    'jitter': np.random.normal(2, 0.5, n),
    'carga_cpu_router': np.nan,
    'uso_memoria_sw': np.random.normal(40, 10, n),
    'peticiones_http': np.random.normal(200, 50, n)
})

# Crear dependencias (redundancia) igual que en R
datos_red['bytes_enviados'] = datos_red['paquetes_enviados'] * 1500 + np.random.normal(0, 500, n)
datos_red['reintentos_tcp'] = datos_red['errores_checksum'] * 1.5 + np.random.normal(0, 0.5, n)
datos_red['carga_cpu_router'] = (datos_red['paquetes_enviados'] * 0.4) + (datos_red['latencia_avg'] * 0.2)

# Mostrar las primeras filas
print("Primeras filas de los datos:")
print(datos_red.head(), "\n")

# ------------------------------------------------------
# Paso 2: Estandarización (Scaling)
# ------------------------------------------------------
# El PCA es sensible a las escalas, estandarizamos a media 0 y desviación estándar 1
escalador = StandardScaler()
datos_escalados = escalador.fit_transform(datos_red)

# Aplicar PCA (equivalente a prcomp con center=TRUE y scale.=TRUE)
pca = PCA(n_components=None)  # Calcula todos los componentes
pca_resultados = pca.fit(datos_escalados)

# ------------------------------------------------------
# Paso 3: Análisis de Varianza
# ------------------------------------------------------
# Varianza explicada por cada componente
varianza_explicada = pca.explained_variance_ratio_
varianza_acumulada = np.cumsum(varianza_explicada)

print("=== Resumen de Varianza Explicada ===")
for i, (var, acum) in enumerate(zip(varianza_explicada, varianza_acumulada), 1):
    print(f"Componente {i}: Varianza = {var:.3f} | Acumulada = {acum:.3f}")

# Gráfica de codo (Scree Plot)
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(varianza_explicada)+1), varianza_explicada, marker='o', linestyle='-')
plt.title('Scree Plot: Tráfico de Red')
plt.xlabel('Número de Componente Principal')
plt.ylabel('Proporción de Varianza Explicada')
plt.grid(True)
plt.show()

# ------------------------------------------------------
# Paso 4: Interpretación de Cargas (Loadings)
# ------------------------------------------------------
# Obtener los pesos (cargas) de cada variable en los componentes
cargas = pd.DataFrame(
    pca.components_.T,
    index=datos_red.columns,
    columns=[f'PC{i+1}' for i in range(pca.n_components_)]
)

print("\n=== Cargas de las variables (PC1 y PC2) ===")
print(round(cargas[['PC1', 'PC2']], 3))

# Interpretación:
# - PC1: valores altos en paquetes_enviados, bytes_enviados, carga_cpu_router -> Volumen de Tráfico
# - PC2: valores altos en latencia_avg, jitter -> Calidad/Estabilidad de Conexión

# ------------------------------------------------------
# Paso 5: Visualización (Biplot)
# ------------------------------------------------------
# Proyectar los datos en los primeros 2 componentes
proyeccion = pca.transform(datos_escalados)

plt.figure(figsize=(10, 8))
# Puntos de las observaciones
plt.scatter(proyeccion[:, 0], proyeccion[:, 1], alpha=0.6, s=15)

# Flechas de las variables originales
escala_flechas = 3  # Ajusta para ver mejor las etiquetas
for var, (x, y) in zip(datos_red.columns, cargas[['PC1', 'PC2']].values):
    plt.arrow(0, 0, x * escala_flechas, y * escala_flechas, color='red', alpha=0.7, head_width=0.1)
    plt.text(x * escala_flechas * 1.15, y * escala_flechas * 1.15, var, color='darkred', ha='center', va='center')

plt.title('Mapa de Estado de Red (Biplot)')
plt.xlabel(f'PC1 ({varianza_explicada[0]:.1%} varianza)')
plt.ylabel(f'PC2 ({varianza_explicada[1]:.1%} varianza)')
plt.axhline(0, color='gray', linestyle='--', alpha=0.5)
plt.axvline(0, color='gray', linestyle='--', alpha=0.5)
plt.grid(True)
plt.show()