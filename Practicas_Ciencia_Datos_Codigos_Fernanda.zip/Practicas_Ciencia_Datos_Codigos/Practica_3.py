# ---------------------------
# Práctica 3: Logística Global
# ---------------------------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr, ttest_ind

sns.set_style("whitegrid")
np.random.seed(123)

# ==============================================
# FASE 1: Calidad de Datos
# ==============================================

# 1. Generar datos simulados (600 envíos)
n = 600
tipo_transporte = np.random.choice(["Terrestre", "Aéreo"], size=n, p=[0.6, 0.4])
distancia_km = np.random.normal(loc=300, scale=150, size=n).clip(50, 1200)
tiempo_entrega_hrs = np.where(
    tipo_transporte == "Terrestre",
    2 + 0.05 * distancia_km + np.random.normal(0, 1.5, n),
    1 + 0.02 * distancia_km + np.random.normal(0, 0.8, n)
)
costo_envio = np.where(
    tipo_transporte == "Terrestre",
    10 + 0.2 * distancia_km,
    50 + 0.8 * distancia_km
)

# Crear DataFrame
df_log = pd.DataFrame({
    "tipo_transporte": tipo_transporte,
    "distancia_km": distancia_km,
    "tiempo_entrega_hrs": tiempo_entrega_hrs,
    "costo_envio": costo_envio
})

# Introducir valores faltantes en distancia
df_log.loc[np.random.choice(n, 15), "distancia_km"] = np.nan

# Limpieza: Imputar con la mediana
print("=== VALORES FALTANTES ANTES ===")
print(df_log.isnull().sum())
mediana_dist = df_log["distancia_km"].median()
df_log["distancia_km"] = df_log["distancia_km"].fillna(mediana_dist)
print("\nValores faltantes DESPUÉS de imputar:", df_log.isnull().sum().sum())

# 2. Estadísticos de tiempo de entrega
media_tiempo = df_log["tiempo_entrega_hrs"].mean()
desv_tiempo = df_log["tiempo_entrega_hrs"].std()
print(f"\nMedia tiempo entrega: {media_tiempo:.2f} horas")
print(f"Desviación estándar: {desv_tiempo:.2f} horas\n")

# ==============================================
# FASE 2: Análisis de Relaciones
# ==============================================

corr_dist_tiempo, p_val = pearsonr(df_log["distancia_km"], df_log["tiempo_entrega_hrs"])
print("=== CORRELACIÓN DISTANCIA - TIEMPO ===")
print(f"Coeficiente Pearson: {corr_dist_tiempo:.3f}")
print("¿Es fuerte? Sí, hay una correlación positiva considerable, pero depende del transporte.\n")

# ==============================================
# FASE 3: Comparativa de Modalidades
# ==============================================

# 1. Promedios por transporte
resumen_transporte = df_log.groupby("tipo_transporte").agg(
    tiempo_promedio = ("tiempo_entrega_hrs", "mean"),
    costo_promedio = ("costo_envio", "mean")
)
print("=== RESUMEN POR TRANSPORTE ===")
print(resumen_transporte, "\n")

# 2. Prueba T de Student
tiempo_terrestre = df_log[df_log["tipo_transporte"] == "Terrestre"]["tiempo_entrega_hrs"]
tiempo_aereo = df_log[df_log["tipo_transporte"] == "Aéreo"]["tiempo_entrega_hrs"]
t_stat, p_valor = ttest_ind(tiempo_terrestre, tiempo_aereo, equal_var=False)
print("=== PRUEBA DE HIPÓTESIS (T-TEST) ===")
print(f"Estadístico t: {t_stat:.2f}")
print(f"P-valor: {p_valor:.4f}")
print("Conclusión: Como p < 0.05, hay diferencia SIGNIFICATIVA en tiempos entre transporte.\n")

# ==============================================
# FASE 4: Visualización
# ==============================================

# 1. Gráfico de dispersión
plt.figure(figsize=(9,5))
sns.scatterplot(data=df_log, x="distancia_km", y="tiempo_entrega_hrs", 
                hue="tipo_transporte", alpha=0.7, palette=["#2ecc71", "#3498db"])
plt.title("Distancia vs Tiempo de Entrega")
plt.xlabel("Distancia (km)")
plt.ylabel("Tiempo (horas)")
plt.savefig("scatter_logistica.png")
plt.show()

# 2. Boxplot tiempos
plt.figure(figsize=(7,5))
sns.boxplot(data=df_log, x="tipo_transporte", y="tiempo_entrega_hrs", palette=["#2ecc71", "#3498db"])
plt.title("Comparación de Tiempos de Entrega")
plt.ylabel("Horas")
plt.savefig("boxplot_tiempos.png")
plt.show()

# ==============================================
# RECOMENDACIÓN FINAL
# ==============================================
print("=== RECOMENDACIÓN ===")
print("El transporte aéreo es mucho más rápido pero más costoso. Para mejorar la satisfacción")
print("del cliente, se recomienda migrar envíos prioritarios o de larga distancia al transporte aéreo,")
print("manteniendo terrestre para envíos cortos y de menor urgencia, equilibrando costo y velocidad.")