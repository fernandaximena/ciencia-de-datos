# Importar librerías necesarias
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score
from sklearn.cluster import KMeans

# ==================================================
# Paso 1: Simulación de Tráfico de Red
# ==================================================
np.random.seed(444)
n = 400

# Generar variables de entrada
df_red = pd.DataFrame({
    'latencia': np.random.normal(20, 5, n),
    'intentos_fallidos': np.random.poisson(1, n),
    'tamano_paquete': np.random.normal(500, 100, n)
})

# Regla de clasificación: Ataque (1) si intentos > 2 o latencia > 35, de lo contrario Seguro (0)
df_red['es_ataque'] = np.where(
    (df_red['intentos_fallidos'] > 2) | (df_red['latencia'] > 35),
    1, 0
)

print("=== Primeras filas del conjunto de datos ===")
print(df_red.head(), "\n")

# Separar características y variable objetivo
X = df_red[['latencia', 'intentos_fallidos', 'tamano_paquete']]
y = df_red['es_ataque']

# ==================================================
# Paso 2: Modelo de Regresión Logística
# ==================================================
modelo_log = LogisticRegression()
modelo_log.fit(X, y)

print("=== Resumen Regresión Logística ===")
print(f"Intercepto: {modelo_log.intercept_[0]:.4f}")
print("Coeficientes de las variables:")
for nombre, coef in zip(X.columns, modelo_log.coef_[0]):
    print(f"  - {nombre}: {coef:.4f}")
print("\nInterpretación: Valores de coeficientes altos indican mayor peso para detectar ataques\n")

# ==================================================
# Paso 3: Clasificación con KNN (con Validación Cruzada)
# ==================================================
# Escalamiento obligatorio para KNN
escalador = StandardScaler()
X_escalado = escalador.fit_transform(X)

# Probar valores de k de 1 a 10
k_valores = list(range(1, 11))
precisiones = []

# Validación cruzada de 5 pliegues
for k in k_valores:
    modelo_knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(modelo_knn, X_escalado, y, cv=5, scoring='accuracy')
    precisiones.append(scores.mean())

# Gráfico de precisión según valor de K
plt.figure(figsize=(8, 5))
plt.plot(k_valores, precisiones, marker='o', linestyle='-', color='green')
plt.title('Precisión del modelo KNN según número de vecinos')
plt.xlabel('Número de vecinos (k)')
plt.ylabel('Precisión media (Validación 5-fold)')
plt.xticks(k_valores)
plt.grid(True, alpha=0.3)
plt.show()

# Encontrar el mejor K
mejor_k = k_valores[precisiones.index(max(precisiones))]
print(f"=== Mejor valor de K: {mejor_k} con precisión de {max(precisiones):.4f} ===\n")

# ==================================================
# Paso 4: Análisis de Resultados (Clustering K-Means)
# ==================================================
# Usamos solo las métricas, SIN la etiqueta de ataque
datos_clust = X_escalado.copy()

# Aplicar K-Means con 2 grupos
kmeans = KMeans(n_clusters=2, random_state=111)
df_red['cluster'] = kmeans.fit_predict(datos_clust)

# Tabla de comparación: Etiqueta real vs Cluster asignado
tabla_comparacion = pd.crosstab(
    df_red['es_ataque'],
    df_red['cluster'],
    rownames=['Real: Es Ataque'],
    colnames=['Cluster Asignado']
)

print("=== Comparación: Etiqueta Real vs Agrupación K-Means ===")
print(tabla_comparacion)
print("\nInterpretación: Si un cluster agrupa mayormente 1s y el otro 0s, el algoritmo detectó patrones sin supervisión.")