# ==================================================
# PRÁCTICA: REDUCCIÓN DE DIMENSIONALIDAD - METAL-TECH
# FECHA: 2026-06-04 20:20:21
# ==================================================

# ----------------------
# 1. IMPORTAR LIBRERÍAS
# ----------------------
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import os # Esta librería sirve para crear la carpeta donde guardaremos todo

# ----------------------
# CREAR CARPETA DESTINO
# ----------------------
# Creamos una carpeta llamada "Resultados_PCA" si no existe aún
if not os.path.exists("Resultados_PCA"):
    os.makedirs("Resultados_PCA")
print("✅ Carpeta 'Resultados_PCA' creada o ya existente.")

# ==================================================
# 2. METODOLOGÍA Y CARGA DE DATOS
# ==================================================
print("\n🔹 PASO 2: Generando datos de sensores...")

np.random.seed(42) # Equivalente a set.seed(42) en R
n = 200

# Generación de variables correlacionadas igual que en tu código R
temp1 = np.random.normal(loc=100, scale=5, size=n)
temp2 = temp1 + np.random.normal(loc=0, scale=1, size=n)
presion1 = np.random.normal(loc=50, scale=10, size=n)
vibracion = (temp1 * 0.5) + np.random.normal(loc=0, scale=2, size=n)

# Crear DataFrame con los 12 sensores
datos_sensores = pd.DataFrame({
    'temp_nucleo': temp1,
    'temp_escape': temp2,
    'presion_interna': presion1,
    'vibracion_motor': vibracion,
    'flujo_gas': np.random.normal(loc=20, scale=2, size=n),
    'oxigeno': np.random.normal(loc=15, scale=1, size=n),
    'co2': temp1 * 0.2 + np.random.normal(loc=0, scale=0.5, size=n),
    'humedad': np.random.uniform(low=30, high=40, size=n),
    'voltaje': np.random.normal(loc=220, scale=2, size=n),
    'corriente': np.random.normal(loc=15, scale=0.5, size=n),
    'ruido_db': vibracion * 1.2 + np.random.normal(loc=0, scale=1, size=n),
    'eficiencia': 100 - (temp1 * 0.1)
})

# Mostrar en pantalla (equivalente a head())
print(datos_sensores.head())

# 💾 GUARDADO 1: Datos originales
datos_sensores.to_csv("Resultados_PCA/01_datos_originales.csv", index=False)
print("   ✅ Guardado: 01_datos_originales.csv")

# ==================================================
# 3. EJECUCIÓN DEL ALGORITMO PCA
# ==================================================
print("\n🔹 PASO 3: Ejecutando PCA...")

# Estandarizar datos (center=TRUE, scale.=TRUE)
escalador = StandardScaler()
datos_escalados = escalador.fit_transform(datos_sensores)

# 💾 GUARDADO 2: Datos escalados/estandarizados
pd.DataFrame(datos_escalados, columns=datos_sensores.columns).to_csv("Resultados_PCA/02_datos_escalados.csv", index=False)
print("   ✅ Guardado: 02_datos_escalados.csv")

# Aplicar modelo PCA
pca_modelo = PCA()
pca_modelo.fit(datos_escalados)

# Resumen de varianza (equivalente a summary(pca_modelo))
varianza_explicada = pca_modelo.explained_variance_ratio_
varianza_acumulada = np.cumsum(varianza_explicada)

resumen_varianza = pd.DataFrame({
    'Varianza_Explicada_Individual': varianza_explicada.round(4),
    'Varianza_Explicada_Acumulada': varianza_acumulada.round(4)
}, index=[f'PC{i+1}' for i in range(len(varianza_explicada))])

print(resumen_varianza)

# 💾 GUARDADO 3: Resumen de varianza
resumen_varianza.to_csv("Resultados_PCA/03_resumen_varianza.csv")
print("   ✅ Guardado: 03_resumen_varianza.csv")

# Guardamos también los valores calculados de cada componente para usarlos después
componentes = pca_modelo.transform(datos_escalados)
pd.DataFrame(componentes, columns=[f'PC{i+1}' for i in range(componentes.shape[1])]).to_csv("Resultados_PCA/04_valores_componentes.csv", index=False)
print("   ✅ Guardado: 04_valores_componentes.csv")

# ==================================================
# 4. ANÁLISIS DE RESULTADOS
# ==================================================

# ----------------------
# 4.1 Gráfico de Sedimentación
# ----------------------
print("\n🔹 PASO 4.1: Generando Gráfico de Sedimentación...")

plt.figure(figsize=(10, 6))
plt.plot(range(1, len(varianza_explicada)+1), varianza_explicada, marker='o', linestyle='-', color='blue', label='Varianza Individual')
plt.plot(range(1, len(varianza_acumulada)+1), varianza_acumulada, marker='s', linestyle='--', color='green', label='Varianza Acumulada')

# Líneas de referencia solicitadas
plt.axhline(y=1/len(datos_sensores.columns), color='red', linestyle='--', label='Criterio Kaiser (valor > 1)')
plt.axhline(y=0.85, color='orange', linestyle=':', label='Objetivo 85% Varianza')

plt.title('Gráfico de Sedimentación (Scree Plot)')
plt.xlabel('Número de Componentes Principales')
plt.ylabel('Proporción de Varianza')
plt.legend()
plt.grid(True)

# 💾 GUARDADO 4: Gráfico de sedimentación
plt.savefig("Resultados_PCA/05_grafico_sedimentacion.png", dpi=300, bbox_inches='tight')
plt.close() # Cerramos la figura para no mezclar con la siguiente
print("   ✅ Guardado: 05_grafico_sedimentacion.png")

# ----------------------
# 4.2 Cargas de los Componentes (Loadings)
# ----------------------
print("\n🔹 PASO 4.2: Analizando Cargas...")

# Equivalente a pca_modelo$rotation
cargas = pd.DataFrame(
    pca_modelo.components_.T,
    index=datos_sensores.columns,
    columns=[f'PC{i+1}' for i in range(pca_modelo.n_components_)]
)

# Mostrar solo los primeros 2 redondeados a 3 decimales
print(cargas[['PC1', 'PC2']].round(3))

# 💾 GUARDADO 5: Cargas completas
cargas.round(3).to_csv("Resultados_PCA/06_cargas_componentes.csv")
print("   ✅ Guardado: 06_cargas_componentes.csv")

# ----------------------
# 4.3 Visualización del Biplot
# ----------------------
print("\n🔹 PASO 4.3: Generando Biplot...")

plt.figure(figsize=(12, 8))

# Graficar puntos de datos
plt.scatter(componentes[:, 0], componentes[:, 1], alpha=0.6, color='lightblue')

# Graficar vectores de las variables originales
escala = 5 # Factor para que se vean bien las flechas
for i, var in enumerate(datos_sensores.columns):
    plt.arrow(0, 0, cargas.iloc[i, 0]*escala, cargas.iloc[i, 1]*escala, color='red', alpha=0.7, head_width=0.1)
    plt.text(cargas.iloc[i, 0]*escala*1.1, cargas.iloc[i, 1]*escala*1.1, var, color='darkred', fontsize=9)

plt.title('Biplot de Sensores Industriales')
plt.xlabel(f'PC1 ({varianza_explicada[0]:.1%} varianza)')
plt.ylabel(f'PC2 ({varianza_explicada[1]:.1%} varianza)')
plt.grid(True)

# 💾 GUARDADO 6: Biplot
plt.savefig("Resultados_PCA/07_biplot.png", dpi=300, bbox_inches='tight')
plt.close()
print("   ✅ Guardado: 07_biplot.png")

# ==================================================
# FINALIZACIÓN
# ==================================================
print("\n🎉 ¡PROCESO FINALIZADO!")
print("Todos los archivos están guardados en la carpeta 'Resultados_PCA'")