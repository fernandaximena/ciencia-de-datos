# Importar las librerías necesarias
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# ==================================================
# Paso 1: Generación de Datos Urbanos
# ==================================================
np.random.seed(456)  # Equivalente a set.seed(456) en R
n = 400

# Crear DataFrame con las mediciones de los sensores
datos_urbanos = pd.DataFrame({
    'temp_ambiente': np.random.normal(28, 4, n),
    'humedad_rel': np.random.normal(60, 10, n),
    'co2_ppm': np.nan,              # Se calculará después
    'no2_ppb': np.nan,              # Se calculará después
    'particulas_pm25': np.nan,      # Se calculará después
    'nivel_ruido_db': np.nan,       # Se calculará después
    'densidad_vehiculos': np.random.normal(120, 30, n),
    'velocidad_viento': np.random.normal(15, 5, n),
    'radiacion_solar': np.random.normal(800, 100, n),
    'conteo_peatones': np.random.normal(50, 15, n)
})

# Generar correlaciones y redundancia (lógica de ciudad)
datos_urbanos['co2_ppm'] = (datos_urbanos['densidad_vehiculos'] * 3.5) + np.random.normal(300, 50, n)
datos_urbanos['no2_ppb'] = (datos_urbanos['co2_ppm'] * 0.1) + np.random.normal(5, 2, n)
datos_urbanos['particulas_pm25'] = (datos_urbanos['co2_ppm'] * 0.05) + np.random.normal(10, 3, n)
datos_urbanos['nivel_ruido_db'] = (datos_urbanos['densidad_vehiculos'] * 0.2) + 50 + np.random.normal(0, 5, n)

# Mostrar las primeras filas para ver la estructura
print("=== Primeras filas de los datos de sensores ===")
print(datos_urbanos.head(), "\n")

# ==================================================
# Paso 2: Estandarización de las Métricas
# ==================================================
# Escalamos para que todas las variables tengan media 0 y desviación estándar 1
escalador = StandardScaler()
datos_escalados = escalador.fit_transform(datos_urbanos)

# Aplicamos PCA (equivalente a prcomp con center=TRUE y scale.=TRUE)
pca_ciudad = PCA()
pca_ciudad.fit(datos_escalados)

# ==================================================
# Paso 3: Análisis de Varianza Acumulada
# ==================================================
varianza_explicada = pca_ciudad.explained_variance_ratio_
varianza_acumulada = np.cumsum(varianza_explicada)

print("=== Resumen de Varianza Explicada ===")
for i, (var, acum) in enumerate(zip(varianza_explicada, varianza_acumulada), 1):
    print(f"Componente {i}: Varianza individual = {var:.3f} | Varianza acumulada = {acum:.3f}")

# Gráfica Scree Plot
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(varianza_explicada)+1), varianza_explicada, marker='o', linestyle='-')
plt.axhline(y=1/len(datos_urbanos.columns), color='red', linestyle='--', label='Umbral referencia')
plt.title("Scree Plot: Sensores Smart City")
plt.xlabel("Número de Componentes Principales")
plt.ylabel("Proporción de Varianza Explicada")
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# ==================================================
# Paso 4: Interpretación de los Componentes (Loadings)
# ==================================================
# Convertimos los pesos en un DataFrame para verlo claro
cargas = pd.DataFrame(
    pca_ciudad.components_.T,
    index=datos_urbanos.columns,
    columns=[f'PC{i+1}' for i in range(pca_ciudad.n_components_)]
)

print("\n=== Pesos de las variables en PC1 y PC2 ===")
print(round(cargas[['PC1', 'PC2']], 3))

# Interpretación esperada:
# - PC1: Valores altos en densidad_vehiculos, co2_ppm, no2_ppb, particulas_pm25, nivel_ruido_db → Representa: Actividad e Impacto Vehicular
# - PC2: Valores altos en temp_ambiente, humedad_rel, radiacion_solar → Representa: Factor Climático / Meteorológico

# ==================================================
# Paso 5: El Biplot de Diagnóstico Urbano
# ==================================================
# Proyectamos los datos sobre los dos primeros componentes
proyeccion = pca_ciudad.transform(datos_escalados)

plt.figure(figsize=(10, 8))
# Dibujamos los puntos (mediciones de sensores)
plt.scatter(proyeccion[:, 0], proyeccion[:, 1], alpha=0.6, s=15)

# Dibujamos las flechas de cada variable original
escala_flechas = 3  # Ajusta el tamaño de las flechas para ver bien las etiquetas
for variable, (x, y) in zip(datos_urbanos.columns, cargas[['PC1', 'PC2']].values):
    plt.arrow(0, 0, x * escala_flechas, y * escala_flechas, 
              color='red', alpha=0.7, head_width=0.1)
    plt.text(x * escala_flechas * 1.15, y * escala_flechas * 1.15, 
             variable, color='darkred', ha='center', va='center')

# Detalles del gráfico
plt.title("Mapa Biplot de Estado Urbano")
plt.xlabel(f"PC1: Actividad Vehicular ({varianza_explicada[0]:.1%} varianza)")
plt.ylabel(f"PC2: Factor Climático ({varianza_explicada[1]:.1%} varianza)")
plt.axhline(0, color='gray', linestyle='--', alpha=0.5)
plt.axvline(0, color='gray', linestyle='--', alpha=0.5)
plt.grid(True, alpha=0.3)
plt.show()