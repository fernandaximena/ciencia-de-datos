# Importar librerías necesarias
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score, mean_squared_error
import math

# ==================================================
# Paso 1: Preparación del Dataset
# ==================================================
np.random.seed(789)  # Equivalente a set.seed(789) en R
n = 500

# Crear variables predictoras
df_empleados = pd.DataFrame({
    'experiencia': np.random.normal(5, 2, n),
    'certificaciones': np.random.poisson(3, n),
    'habilidades_sociales': np.random.uniform(1, 10, n),
    'remoto': np.random.choice([0, 1], size=n, replace=True)
})

# Variable objetivo continua: Salario
df_empleados['salario'] = 25000 + (df_empleados['experiencia'] * 5000) + \
                          (df_empleados['certificaciones'] * 2000) + np.random.normal(0, 3000, n)

# Variable objetivo binaria: Retención (1=Se queda, 0=Se va)
# Función logística para probabilidad
def logistica(x):
    return 1 / (1 + np.exp(-x))

prob = logistica(-2 + 0.0001 * df_empleados['salario'] + 0.2 * df_empleados['habilidades_sociales'])
df_empleados['retencion'] = np.where(np.random.uniform(size=n) < prob, 1, 0)
df_empleados['retencion'] = df_empleados['retencion'].astype('category')

print("=== Primeras filas del conjunto de datos ===")
print(df_empleados.head(), "\n")

# ==================================================
# Paso 2: Regresión Lineal (Predecir Salario)
# ==================================================
# División 80% entrenamiento, 20% prueba
X_reg = df_empleados[['experiencia', 'certificaciones']]
y_reg = df_empleados['salario']

X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=123
)

# Entrenamiento del modelo
modelo_regresion = LinearRegression()
modelo_regresion.fit(X_train_reg, y_train_reg)

# Resultados y coeficientes
print("=== Modelo de Regresión Lineal ===")
print(f"Intercepto: {modelo_regresion.intercept_:.2f}")
print(f"Coeficientes:")
for nombre, coef in zip(X_reg.columns, modelo_regresion.coef_):
    print(f"  - {nombre}: {coef:.2f}")

# Evaluación
y_pred_reg = modelo_regresion.predict(X_test_reg)
mse = mean_squared_error(y_test_reg, y_pred_reg)
print(f"Error Cuadrático Medio (MSE): {mse:.2f}")
print(f"Raíz del Error Cuadrático Medio (RMSE): {math.sqrt(mse):.2f}\n")

# ==================================================
# Paso 3: Clasificación KNN (Predecir Retención)
# ==================================================
# Variables para clasificación
X_clf = df_empleados[['experiencia', 'habilidades_sociales', 'salario']]
y_clf = df_empleados['retencion']

X_train_clf, X_test_clf, y_train_clf, y_test_clf = train_test_split(
    X_clf, y_clf, test_size=0.2, random_state=123
)

# Escalamiento (obligatorio para KNN)
escalador = StandardScaler()
X_train_esc = escalador.fit_transform(X_train_clf)
X_test_esc = escalador.transform(X_test_clf)

# Probar diferentes valores de K (equivalente a tuneLength=5)
valores_k = [1, 3, 5, 7, 9]
precisiones = []

print("=== Desempeño KNN según valor de K ===")
for k in valores_k:
    modelo_knn = KNeighborsClassifier(n_neighbors=k)
    modelo_knn.fit(X_train_esc, y_train_clf)
    pred = modelo_knn.predict(X_test_esc)
    acc = accuracy_score(y_test_clf, pred)
    precisiones.append(acc)
    print(f"K = {k} | Precisión: {acc:.4f}")

# Seleccionar y entrenar el mejor modelo
mejor_k = valores_k[precisiones.index(max(precisiones))]
modelo_knn_final = KNeighborsClassifier(n_neighbors=mejor_k)
modelo_knn_final.fit(X_train_esc, y_train_clf)
print(f"\nMejor modelo: K = {mejor_k} con precisión de {max(precisiones):.4f}\n")

# ==================================================
# Paso 4: Clustering No Supervisado (K-Means)
# ==================================================
# Seleccionar y escalar datos
datos_clust = df_empleados[['experiencia', 'salario']].copy()
datos_clust_esc = StandardScaler().fit_transform(datos_clust)

# Entrenar K-Means con 3 grupos
kmeans = KMeans(n_clusters=3, random_state=456, n_init='auto')
df_empleados['cluster'] = kmeans.fit_predict(datos_clust_esc)
df_empleados['cluster'] = df_empleados['cluster'].astype('category')

# Visualización de los grupos
plt.figure(figsize=(10, 6))
colores = ['#1f77b4', '#ff7f0e', '#2ca02c']
etiquetas = ['Junior', 'Medio', 'Senior']  # Interpretación esperada

for i in range(3):
    datos_grupo = df_empleados[df_empleados['cluster'] == i]
    plt.scatter(
        datos_grupo['experiencia'], 
        datos_grupo['salario'],
        color=colores[i],
        label=etiquetas[i],
        alpha=0.7
    )

plt.title("Segmentación de Empleados por Perfil (K-Means)")
plt.xlabel("Experiencia (años)")
plt.ylabel("Salario ($)")
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()