# Importar librerías necesarias
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import os

# Crear carpeta para guardar todos los archivos (si no existe)
if not os.path.exists("Resultados_PCA"):
    os.makedirs("Resultados_PCA")

# -----------------------------------------------------------------------------
# 2. Metodología y Carga de Datos
# -----------------------------------------------------------------------------
np.random.seed(42)
n = 200

# Generar variables igual que en la práctica
temp1 = np.random.normal(100, 5, n)
temp2 = temp1 + np.random.normal(0, 1, n)
presion1 = np.random.normal(50, 10, n)
vibracion = (temp1 * 0.5) + np.random.normal(0, 2, n)

datos_sensores = pd.DataFrame({
    'temp_nucleo': temp1,
    'temp_escape': temp2,
    'presion_interna': presion1,
    'vibracion_motor': vibracion,
    'flujo_gas': np.random.normal(20, 2, n),
    'oxigeno': np.random.normal(15, 1, n),
    'co2': temp1 * 0.2 + np.random.normal(0, 0.5, n),
    'humedad': np.random.uniform(30, 40, n),
    'voltaje': np.random.normal(220, 2, n),
    'corriente': np.random.normal(15, 0.5, n),
    'ruido_db': vibracion * 1.2 + np.random.normal(0, 1, n),
    'eficiencia': 100 - (temp1 * 0.1)
})

# ✅ Guardar DATOS ORIGINALES
datos_sensores.to_csv("Resultados_PCA/1_datos_sensores_originales.csv", index=False)
print("✅ Datos originales guardados")

# -----------------------------------------------------------------------------
# 3. Ejecución del Algoritmo PCA
# -----------------------------------------------------------------------------
escalador = StandardScaler()
datos_escalados = escalador.fit_transform(datos_sensores)

# ✅ Guardar DATOS ESCALADOS
pd.DataFrame(datos_escalados, columns=datos_sensores.columns).to_csv("Resultados_PCA/2_datos_escalados.csv", index=False)
print("✅ Datos escalados guardados")

pca_modelo = PCA()
componentes = pca_modelo.fit_transform(datos_escalados)

# ✅ Guardar VALORES DE LOS COMPONENTES PRINCIPALES (nuevas variables)
pd.DataFrame(componentes, columns=[f'PC{i+1}' for i in range(componentes.shape[1])]).to_csv("Resultados_PCA/3_componentes_principales.csv", index=False)
print("✅ Componentes principales guardados")

# Resumen de varianza
varianza_explicada = pca_modelo.explained_variance_ratio_
varianza_acumulada = np.cumsum(varianza_explicada)

# ✅ Guardar RESUMEN DE VARIANZA
resumen_varianza = pd.DataFrame({
    'Componente': [f'PC{i+1}' for i in range(len(varianza_explicada))],
    'Varianza_Explicada': varianza_explicada.round(4),
    'Varianza_Acumulada': varianza_acumulada.round(4)
})
resumen_varianza.to_csv("Resultados_PCA/4_resumen_varianza.csv", index=False)
print("✅ Resumen de varianza guardado")

# -----------------------------------------------------------------------------
# 4.1 Selección de Componentes (Scree Plot)
# -----------------------------------------------------------------------------
plt.figure(figsize=(10, 6))
plt.plot(range(1, len(varianza_explicada)+1), varianza_explicada, marker='o', linestyle='-', color='blue', label='Varianza individual')
plt.plot(range(1, len(varianza_acumulada)+1), varianza_acumulada, marker='s', linestyle='--', color='green', label='Varianza acumulada')
plt.axhline(y=0.85, color='red', linestyle=':', label='Umbral 85% varianza')
plt.axhline(y=1/len(datos_sensores.columns), color='gray', linestyle='--', label='Criterio Kaiser')
plt.title('Gráfico de Sedimentación (Scree Plot)')
plt.xlabel('Número de Componentes Principales')
plt.ylabel('Proporción de Varianza Explicada')
plt.legend()
plt.grid(True)

# ✅ Guardar GRÁFICO DE SEDIMENTACIÓN
plt.savefig("Resultados_PCA/5_grafico_sedimentacion.png", dpi=300, bbox_inches='tight')
plt.close()
print("✅ Gráfico de sedimentación guardado")

# -----------------------------------------------------------------------------
# 4.2 Cargas de los Componentes (Loadings)
# -----------------------------------------------------------------------------
cargas = pd.DataFrame(
    pca_modelo.components_.T,
    index=datos_sensores.columns,
    columns=[f'PC{i+1}' for i in range(pca_modelo.n_components_)]
)

# ✅ Guardar CARGAS (pesos de cada variable)
cargas.round(3).to_csv("Resultados_PCA/6_cargas_componentes.csv")
print("✅ Cargas de componentes guardadas")

# -----------------------------------------------------------------------------
# 4.3 Visualización del Biplot
# -----------------------------------------------------------------------------
plt.figure(figsize=(12, 8))
plt.scatter(componentes[:, 0], componentes[:, 1], alpha=0.6, color='lightblue')

for i, var in enumerate(datos_sensores.columns):
    plt.arrow(0, 0, cargas.iloc[i, 0]*5, cargas.iloc[i, 1]*5, color='red', alpha=0.7, head_width=0.1)
    plt.text(cargas.iloc[i, 0]*5.2, cargas.iloc[i, 1]*5.2, var, color='darkred', fontsize=9)

plt.title('Biplot: Componentes Principales vs Variables Originales')
plt.xlabel(f'PC1 ({varianza_explicada[0]:.1%} varianza)')
plt.ylabel(f'PC2 ({varianza_explicada[1]:.1%} varianza)')
plt.grid(True)

# ✅ Guardar BIPLOT
plt.savefig("Resultados_PCA/7_biplot.png", dpi=300, bbox_inches='tight')
plt.close()
print("✅ Biplot guardado")

print("\n🎉 ¡Todo ha sido guardado correctamente en la carpeta 'Resultados_PCA'!")
