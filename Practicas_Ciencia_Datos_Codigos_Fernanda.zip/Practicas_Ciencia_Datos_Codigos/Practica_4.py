# ==================================================
# PRÁCTICA 4: REDUCCIÓN DE DIMENSIONALIDAD - PCA
# ==================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import seaborn as sns

sns.set_style("whitegrid")
np.random.seed(42)  # Igual que en el código R original

# ==============================================
# FASE 1: PREPARACIÓN DE DATOS
# ==============================================

# 1. Generar dataset idéntico al ejemplo
n = 200
temp_nucleo = np.random.normal(100, 5, n)
temp_escape = temp_nucleo + np.random.normal(0, 1, n)
presion_interna = np.random.normal(50, 10, n)
vibracion_motor = (temp_nucleo * 0.5) + np.random.normal(0, 2, n)
flujo_gas = np.random.normal(20, 2, n)
oxigeno = np.random.normal(15, 1, n)
co2 = (temp_nucleo * 0.2) + np.random.normal(0, 0.5, n)
humedad = np.random.uniform(30, 40, n)
voltaje = np.random.normal(220, 2, n)
corriente = np.random.normal(15, 0.5, n)
ruido_db = (vibracion_motor * 1.2) + np.random.normal(0, 1, n)
eficiencia = 100 - (temp_nucleo * 0.1)

# Crear DataFrame
datos_sensores = pd.DataFrame({
    "temp_nucleo": temp_nucleo,
    "temp_escape": temp_escape,
    "presion_interna": presion_interna,
    "vibracion_motor": vibracion_motor,
    "flujo_gas": flujo_gas,
    "oxigeno": oxigeno,
    "co2": co2,
    "humedad": humedad,
    "voltaje": voltaje,
    "corriente": corriente,
    "ruido_db": ruido_db,
    "eficiencia": eficiencia
})

print("=== PRIMEROS 5 REGISTROS ===")
print(datos_sensores.head(), "\n")

# 2. Correlación inicial
print("=== MATRIZ DE CORRELACIÓN ===")
matriz_corr = datos_sensores.corr().round(2)
print(matriz_corr)
print("\n✅ Se observa alta correlación entre: temp_nucleo - temp_escape, temp_nucleo - co2, vibracion - ruido\n")

# ==============================================
# FASE 2: EJECUCIÓN DE PCA
# ==============================================

# Estandarización (OBLIGATORIO, igual que scale. = TRUE en R)
escalador = StandardScaler()
datos_escalados = escalador.fit_transform(datos_sensores)

# Aplicar PCA
modelo_pca = PCA()
resultados_pca = modelo_pca.fit_transform(datos_escalados)

# ==============================================
# FASE 3: SELECCIÓN DE COMPONENTES
# ==============================================

# 1. Varianza explicada
varianza = modelo_pca.explained_variance_ratio_
varianza_acumulada = np.cumsum(varianza)

print("=== VARIANZA EXPLICADA ===")
for i, (v, va) in enumerate(zip(varianza, varianza_acumulada)):
    print(f"Componente {i+1}: {v:.3f} | Acumulada: {va:.3f}")

# 2. Scree Plot (Gráfico de sedimentación)
plt.figure(figsize=(8, 5))
plt.plot(range(1, len(varianza)+1), varianza, marker='o', linestyle='-', color='darkblue')
plt.axhline(y=1/len(varianza), color='red', linestyle='--', label='Umbral Kaiser')
plt.title("Gráfico de Sedimentación (Scree Plot)")
plt.xlabel("Componentes Principales")
plt.ylabel("Proporción de Varianza")
plt.legend()
plt.savefig("scree_plot_sensores.png")
plt.show()

# 3. ¿Cuántos componentes para llegar al 85%?
num_componentes = np.argmax(varianza_acumulada >= 0.85) + 1
print(f"\n✅ Se necesitan {num_componentes} componentes para explicar el 85% de la varianza\n")

# 4. Cargas (Loadings) - Pesos en PC1 y PC2
cargas = pd.DataFrame(
    modelo_pca.components_.T[:, :2],
    columns=['PC1', 'PC2'],
    index=datos_sensores.columns
).round(3)

print("=== CARGAS DE LOS COMPONENTES ===")
print(cargas)
print("\n💡 Interpretación:")
print("PC1 = ESTADO TÉRMICO (temperatura, vibración, CO2, ruido)")
print("PC2 = FACTORES INDEPENDIENTES (humedad, voltaje, corriente)\n")

# ==============================================
# FASE 4: VISUALIZACIÓN (Biplot)
# ==============================================

plt.figure(figsize=(10, 7))
# Puntos de observaciones
plt.scatter(resultados_pca[:, 0], resultados_pca[:, 1], alpha=0.6, color='gray')
# Vectores de variables
for variable in datos_sensores.columns:
    plt.arrow(0, 0, cargas.loc[variable, 'PC1'] * 4, cargas.loc[variable, 'PC2'] * 4,
              color='red', alpha=0.7, head_width=0.2)
    plt.text(cargas.loc[variable, 'PC1'] * 4.5, cargas.loc[variable, 'PC2'] * 4.5,
             variable, color='darkred', fontsize=9)

plt.title("Biplot: Sensores Industriales")
plt.xlabel(f"PC1 ({varianza[0]:.1%} varianza)")
plt.ylabel(f"PC2 ({varianza[1]:.1%} varianza)")
plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)
plt.axhline(y=0, color='black', linestyle='--', alpha=0.5)
plt.savefig("biplot_sensores.png")
plt.show()

# ==============================================
# CONCLUSIONES
# ==============================================
print("=== CONCLUSIONES PARA GERENCIA DE TI ===")
print(f"1. Reducción: De 12 a {num_componentes} variables sin perder información crítica.")
print("2. Sensores redundantes: temp_escape, co2, ruido_db (se pueden calcular de otros).")
print("3. Impacto: Menor consumo de ancho de banda (~70% menos), procesamiento más rápido, sin saturación del PLC.")