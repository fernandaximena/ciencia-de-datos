# ==================================================
# PRÁCTICA 5: PCA - TRÁFICO DE RED
# ==================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import seaborn as sns

sns.set_style("whitegrid")
np.random.seed(123) # Igual al código R

# ==============================================
# PASO 1: GENERACIÓN Y EXPLORACIÓN
# ==============================================

n = 300
datos_red = pd.DataFrame({
    "duracion_ms": np.random.normal(50, 10, n),
    "paquetes_enviados": np.random.normal(100, 20, n),
    "errores_checksum": np.random.poisson(2, n),
    "latencia_avg": np.random.normal(15, 5, n),
    "jitter": np.random.normal(2, 0.5, n),
    "uso_memoria_sw": np.random.normal(40, 10, n),
    "peticiones_http": np.random.normal(200, 50, n)
})

# Crear variables redundantes / correlacionadas
datos_red["bytes_enviados"] = datos_red["paquetes_enviados"] * 1500 + np.random.normal(0, 500, n)
datos_red["reintentos_tcp"] = datos_red["errores_checksum"] * 1.5 + np.random.normal(0, 0.5, n)
datos_red["carga_cpu_router"] = (datos_red["paquetes_enviados"] * 0.4) + (datos_red["latencia_avg"] * 0.2)

print("=== DATOS DE RED (PRIMERAS FILAS) ===")
print(datos_red.head(), "\n")

# ==============================================
# PASO 2: ESTANDARIZACIÓN
# ==============================================
escalador = StandardScaler()
datos_escalados = escalador.fit_transform(datos_red)

# ==============================================
# PASO 3: ANÁLISIS DE VARIANZA
# ==============================================
modelo_pca = PCA()
modelo_pca.fit(datos_escalados)

varianza_acumulada = np.cumsum(modelo_pca.explained_variance_ratio_)
print("=== VARIANZA ACUMULADA ===")
for i, var in enumerate(varianza_acumulada):
    print(f"PC{i+1}: {var:.3f}")

# Scree Plot
plt.figure(figsize=(8,5))
plt.plot(modelo_pca.explained_variance_ratio_, marker='o', color='purple')
plt.title("Scree Plot: Tráfico de Red")
plt.xlabel("Componentes")
plt.ylabel("Varianza Explicada")
plt.savefig("scree_red.png")
plt.show()

# ==============================================
# PASO 4: INTERPRETACIÓN DE CARGAS
# ==============================================
cargas = pd.DataFrame(
    modelo_pca.components_.T[:, :2],
    columns=["PC1", "PC2"],
    index=datos_red.columns
).round(3)

print("\n=== CARGAS DE LOS COMPONENTES ===")
print(cargas)
print("\n💡 Significado:")
print("👉 PC1 = VOLUMEN DE TRÁFICO (paquetes, bytes, CPU, peticiones)")
print("👉 PC2 = CALIDAD DE CONEXIÓN (latencia, jitter, errores, reintentos)\n")

# ==============================================
# PASO 5: BIPLOT
# ==============================================
transf_pca = modelo_pca.transform(datos_escalados)

plt.figure(figsize=(10,7))
plt.scatter(transf_pca[:, 0], transf_pca[:, 1], alpha=0.5, color='gray')

# Dibujar vectores
for var in datos_red.columns:
    plt.arrow(0,0, cargas.loc[var,'PC1']*3, cargas.loc[var,'PC2']*3, color='red', alpha=0.7)
    plt.text(cargas.loc[var,'PC1']*3.3, cargas.loc[var,'PC2']*3.3, var, color='darkred')

plt.title("Biplot: Estado de la Red")
plt.xlabel("PC1 - Volumen de Tráfico")
plt.ylabel("PC2 - Calidad / Estabilidad")
plt.savefig("biplot_red.png")
plt.show()

print("✅ CONCLUSIÓN: Puntos alejados del centro indican ANOMALÍAS o posibles ataques.")