# ---------------------------
# Práctica 2: Calidad Industrial
# ---------------------------

# Importar librerías
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr

# Configuración de gráficos
sns.set_style("whitegrid")
np.random.seed(42)  # Para que los datos sean iguales cada vez

# ==============================================
# FASE A: Análisis Exploratorio (EDA)
# ==============================================

# 1. Generar dataset sintético (500 lotes)
n = 500
temperatura = np.random.normal(loc=75, scale=8, size=n)  # Temp operación
presion = np.random.normal(loc=30, scale=5, size=n)
tasa_error = 0.02 * temperatura + np.random.normal(loc=0, scale=0.5, size=n)  # Relación con temp
turno = np.random.choice(["Matutino", "Vespertino"], size=n)

# Crear DataFrame
df = pd.DataFrame({
    "temperatura": temperatura,
    "presion": presion,
    "tasa_error": tasa_error,
    "turno": turno
})

# Agregar valores faltantes (simulación)
df.loc[np.random.choice(n, 10), "temperatura"] = np.nan

# 2. Estadísticos de temperatura
print("=== ESTADÍSTICOS TEMPERATURA ===")
media_temp = df["temperatura"].mean()
mediana_temp = df["temperatura"].median()
desv_temp = df["temperatura"].std()
print(f"Media: {media_temp:.2f}")
print(f"Mediana: {mediana_temp:.2f}")
print(f"Desviación Estándar: {desv_temp:.2f}\n")

# 3. Identificar y limpiar valores faltantes
print("=== VALORES FALTANTES ===")
print(df.isnull().sum())
# Imputar con la media
df["temperatura"] = df["temperatura"].fillna(df["temperatura"].mean())
print("\nValores faltantes después de limpieza:")
print(df.isnull().sum(), "\n")

# 4. Correlación de Pearson entre temperatura y tasa de error
correlacion, p_valor = pearsonr(df["temperatura"], df["tasa_error"])
print("=== CORRELACIÓN PEARSON ===")
print(f"Coeficiente: {correlacion:.3f}")
print(f"P-valor: {p_valor:.4f}")
print("Interpretación: Una correlación positiva indica que mayor temperatura, mayor tasa de error.\n")

# ==============================================
# FASE B: Agrupación y Segmentación
# ==============================================

# 1. Rendimiento promedio por turno
rendimiento_turno = df.groupby("turno")["tasa_error"].mean()
print("=== RENDIMIENTO PROMEDIO POR TURNO ===")
print(rendimiento_turno, "\n")

# 2. Diferencia de temperatura entre turnos
temp_turno = df.groupby("turno")["temperatura"].agg(["mean", "std"])
print("=== TEMPERATURA POR TURNO ===")
print(temp_turno)
print("¿Hay diferencia? Sí, se observan promedios distintos entre turnos.\n")

# ==============================================
# FASE C: Visualización e Interpretación
# ==============================================

# 1. Boxplot: Errores por turno
plt.figure(figsize=(8,5))
sns.boxplot(data=df, x="turno", y="tasa_error", palette="Set2")
plt.title("Distribución de Tasa de Error por Turno")
plt.xlabel("Turno")
plt.ylabel("Tasa de Error")
plt.savefig("boxplot_errores_turno.png")
plt.show()

# 2. Scatter Plot + Línea de regresión
plt.figure(figsize=(8,5))
sns.regplot(data=df, x="temperatura", y="tasa_error", 
            line_kws={"color": "red"}, scatter_kws={"alpha":0.6})
plt.title("Relación: Temperatura vs Tasa de Error")
plt.xlabel("Temperatura de Operación (°C)")
plt.ylabel("Tasa de Error")
plt.savefig("scatter_temp_error.png")
plt.show()

# ==============================================
# CONCLUSIÓN
# ==============================================
print("=== CONCLUSIÓN ===")
print("Existe una relación positiva y significativa entre temperatura y errores de producción.")
print("Las temperaturas más altas incrementan los fallos. Por lo tanto, la empresa SÍ debería invertir")
print("en mejores sistemas de enfriamiento para reducir variaciones y mejorar la calidad.")